# PAN-OS Address/Object Group Management Scripts

This repository contains Python scripts to **export, delete, and recreate** address objects and address groups on **Palo Alto Networks Panorama** using the XML API.

## 📦 Contents

| Script Name                  | Description |
|-----------------------------|-------------|
| `delete_address_objects.py` | Exports and deletes address objects from Panorama, saving a CSV for later reimport. |
| `delete_address_groups.py`  | Exports and deletes address groups from Panorama, saving a CSV for later reimport. |
| `create_address_objects.py` | Recreates address objects from a previously exported CSV. |
| `create_address_groups.py`  | Recreates address groups (static or dynamic) from a previously exported CSV. |

## 📝 Requirements

- Python 3.x
- `requests` module (`pip3 install --user requests`)
- A valid Panorama API key

## 🔐 Authentication

Each script prompts for your Panorama API key using a secure prompt (`getpass`).  
Alternatively, you can create a `.cfg` file to avoid interactive prompts.

### 🔧 `.panos.cfg` Format (INI style)

Place this file in the same directory as your scripts:

```
[PANOS]
host = https://<your-panorama-host>
api_key = <your-api-key>
```

If present, scripts can load the config automatically (requires slight script customization to parse this with `configparser`).

## 📂 CSV Formats

### `address_objects.csv`

| name          | ip-netmask       | description     | location     | type         | tag        |
|---------------|------------------|------------------|--------------|--------------|------------|
| web-server-1  | 192.168.1.10/32  | Web frontend     | Branch-FWs   | ip-netmask   | external   |
| db-server-1   | 192.168.2.20/32  | Database server  | shared       | ip-netmask   | internal   |

### `address_groups.csv`

| name         | members                   | dynamic           | description              | location    | tag       |
|--------------|----------------------------|-------------------|---------------------------|-------------|-----------|
| web-servers  | web-server-1,api-gateway   |                   | Group of all web servers | Branch-FWs  | external  |
| api-group    |                            | 'tag eq dmz'      | Dynamic group for DMZ    | DataCenter  |           |

- **location**: Use `"shared"` for shared config scope, or specify the device group name.
- **members**: Comma-separated object names.
- **dynamic**: Optional expression for dynamic groups.

## ✅ Example Usage

### Delete and Export

```bash
python3 delete_address_objects.py
python3 delete_address_groups.py
```

### Recreate from CSV

```bash
python3 create_address_objects.py
python3 create_address_groups.py
```

## 🔒 Security Notes

- SSL verification is disabled (`verify=False`) for compatibility — secure this for production use.
- Avoid committing `.cfg` files containing secrets to version control.

## 📄 License

MIT License

## 🙋‍♂️ Questions?

Open an issue or contact your automation or security team.